let t = 0;
let player;

let ambientOsc;
let ambientNoise;
let noiseLFO = 0;

let popNoise, popEnv, popFilter;
let nextCrackleTime = 0;

function setup() {
  createCanvas(800, 600);
  noCursor();

 
  player = createVector(width / 2, height / 2 + 100);

  ambientOsc = new p5.Oscillator('triangle');
  ambientOsc.freq(100);
  ambientOsc.amp(0.03, 2); // very soft
  ambientOsc.start();

  ambientNoise = new p5.Noise('pink');
  ambientNoise.amp(0.02);
  ambientNoise.start();

  popNoise = new p5.Noise('white');
  popNoise.start();
  popNoise.amp(0); 

  popEnv = new p5.Envelope();
  popEnv.setADSR(0.001, 0.01, 0, 0);
  popEnv.setRange(0.1, 0);
}

function draw() {
  background(255);

  push();
  translate(sin(t) * 2, cos(t) * 2);
  drawObjects();
  drawPlayer();
  pop();

  drawGrainOverlay();
  maybeGlitch();
  handleMovement();

  let noiseVol = 0.015 + sin(noiseLFO) * 0.01;
  ambientNoise.amp(noiseVol, 0.1);
  noiseLFO += 0.004;

  if (millis() > nextCrackleTime) {
    popEnv.play(popNoise);
    nextCrackleTime = millis() + random(100, 800); 
  }

  t += 0.01;
}

function drawObjects() {
  fill(180);
  rect(width / 2 - 40, height / 2, 80, 40, 5); // Laptop

  fill(120);
  ellipse(width / 2, height / 2 - 80, 40, 40); 

  fill(255, 204, 0);
  ellipse(width / 2, height / 2 - 150, 20, 30); 
}

function drawPlayer() {
  fill(0);
  ellipse(player.x, player.y, 25, 25); 
}

function handleMovement() {
  let speed = 2;
  if (keyIsDown(LEFT_ARROW)) player.x -= speed;
  if (keyIsDown(RIGHT_ARROW)) player.x += speed;
  if (keyIsDown(UP_ARROW)) player.y -= speed;
  if (keyIsDown(DOWN_ARROW)) player.y += speed;
  player.x = constrain(player.x, 0, width);
  player.y = constrain(player.y, 0, height);
}

function drawGrainOverlay() {
  noStroke();
  for (let i = 0; i < 2000; i++) {
    let x = random(width);
    let y = random(height);
    let brightness = random(230, 255);
    fill(brightness, 20);
    rect(x, y, 1, 1);
  }
}

function maybeGlitch() {
  if (random() < 0.005) {
    fill(0, 30);
    rect(0, random(height), width, random(5, 20));
  }
}
